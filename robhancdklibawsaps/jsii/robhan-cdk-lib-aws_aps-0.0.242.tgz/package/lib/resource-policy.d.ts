import { Construct } from 'constructs';
import { ResourcePolicyBase } from './resource-policy-base';
import { IWorkspace } from './workspace-base';
/**
 * Properties for creating an Amazon Managed Service for Prometheus Resource Policy.
 */
export interface ResourcePolicyProps {
    /**
     * The JSON to use as the Resource-based Policy.
     */
    readonly policyDocument: string;
    /**
     * The workspace to attach the policy to.
     */
    readonly workspace: IWorkspace;
}
export declare class ResourcePolicy extends ResourcePolicyBase {
    static isResourcePolicy(x: any): x is ResourcePolicy;
    /**
     * Validates all resource policy properties.
     *
     * @param props - The resource policy properties to validate
     * @returns An array of error messages if validation fails, or an empty array if valid
     *
     * This method aggregates validation results from all individual property validators.
     * It throws an error if props is not an object.
     */
    private static validateProps;
    /**
     * The JSON to use as the Resource-based Policy.
     */
    readonly policyDocument: string;
    /**
     * The workspace to attach the policy to.
     */
    readonly workspace: IWorkspace;
    /**
     * The underlying CloudFormation resource.
     */
    private readonly resourcePolicy;
    constructor(scope: Construct, id: string, props: ResourcePolicyProps);
}
