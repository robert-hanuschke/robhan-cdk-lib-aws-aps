export declare function validateAnomalyDetectorConfiguration(anomalyDetectorConfiguration: unknown): string[];
export declare function validateLabel(label: unknown): string[];
export declare function validateMissingDataAction(missingDataAction: unknown): string[];
export declare function validateAlias(alias: unknown): string[];
export declare function validateEvaluationIntervalInSeconds(evaluationIntervalInSeconds: unknown): string[];
