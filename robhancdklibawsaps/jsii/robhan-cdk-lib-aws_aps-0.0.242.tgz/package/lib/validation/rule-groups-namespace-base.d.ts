/**
 * Validates the data property.
 *
 * @param data - The rule groups namespace data to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 */
export declare function validateData(data: unknown): string[];
/**
 * Validates the name property.
 *
 * @param name - The rule groups namespace name to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 * - Must be between 1 and 64 characters long
 */
export declare function validateName(name: unknown): string[];
