export declare function validateAmpConfiguration(ampConfiguration: unknown): string[];
export declare function validateDestination(destination: unknown): string[];
export declare function validateRoleConfiguration(roleConfiguration: unknown): string[];
export declare function validateScrapeConfiguration(scrapeConfiguration: unknown): string[];
export declare function validateEksConfiguration(eksConfiguration: unknown): string[];
export declare function validateSource(source: unknown): string[];
export declare function validateAlias(alias: unknown): string[];
