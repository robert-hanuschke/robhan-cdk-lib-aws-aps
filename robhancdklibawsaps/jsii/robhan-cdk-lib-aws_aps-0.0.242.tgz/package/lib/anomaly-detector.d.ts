import { Construct } from 'constructs';
import { AnomalyDetectorBase, AnomalyDetectorConfiguration, Label, MissingDataAction } from './anomaly-detector-base';
import { IWorkspace } from './workspace-base';
/**
 * Properties for creating an Amazon Managed Service for Prometheus Anomaly Detector.
 */
export interface AnomalyDetectorProps {
    /**
     * The user-friendly name of the anomaly detector. 1 to 128 characters length.
     */
    readonly alias: string;
    /**
     * The algorithm configuration of the anomaly detector.
     */
    readonly configuration: AnomalyDetectorConfiguration;
    /**
     * The frequency, in seconds, at which the anomaly detector evaluates metrics.
     *
     * Minimum value of 30. Maximum value of 86400.
     */
    readonly evaluationIntervalInSeconds?: number;
    /**
     * The Amazon Managed Service for Prometheus metric labels associated with the anomaly detector.
     *
     * Map Entries: Minimum number of 0 items. Maximum number of 140 items.
     * Key Length Constraints: Minimum length of 1. Maximum length of 7168.
     * Key Pattern: (?!__)[a-zA-Z_][a-zA-Z0-9_]*
     * Value Length Constraints: Minimum length of 1. Maximum length of 7168.
     */
    readonly labels?: Label[];
    /**
     * The action taken when data is missing during evaluation.
     */
    readonly missingDataAction?: MissingDataAction;
    /**
     * An Amazon Managed Service for Prometheus workspace is a logical and isolated Prometheus server dedicated to ingesting, storing, and querying your Prometheus-compatible metrics.
     */
    readonly workspace: IWorkspace;
}
export declare class AnomalyDetector extends AnomalyDetectorBase {
    static isAnomalyDetector(x: any): x is AnomalyDetector;
    /**
     * Validates all anomaly detector properties.
     *
     * @param props - The anomaly detector properties to validate
     * @returns An array of error messages if validation fails, or an empty array if valid
     *
     * This method aggregates validation results from all individual property validators.
     * It throws an error if props is not an object.
     */
    private static validateProps;
    /**
     * The user-friendly name of the anomaly detector. 1 to 64 characters length.
     *
     * Minimum length of 1. Maximum length of 64.
     * Pattern: [0-9A-Za-z][-.0-9A-Z_a-z]*
     */
    readonly alias: string;
    /**
     * The algorithm configuration of the anomaly detector.
     */
    readonly configuration: AnomalyDetectorConfiguration;
    /**
     * The frequency, in seconds, at which the anomaly detector evaluates metrics.
     *
     * Minimum value of 30. Maximum value of 86400.
     */
    readonly evaluationIntervalInSeconds?: number;
    /**
     * The Amazon Managed Service for Prometheus metric labels associated with the anomaly detector.
     *
     * Map Entries: Minimum number of 0 items. Maximum number of 140 items.
     * Key Length Constraints: Minimum length of 1. Maximum length of 7168.
     * Key Pattern: (?!__)[a-zA-Z_][a-zA-Z0-9_]*
     * Value Length Constraints: Minimum length of 1. Maximum length of 7168.
     */
    readonly labels?: Label[];
    /**
     * The action taken when data is missing during evaluation.
     */
    readonly missingDataAction?: MissingDataAction;
    /**
     * An Amazon Managed Service for Prometheus workspace is a logical and isolated Prometheus server dedicated to ingesting, storing, and querying your Prometheus-compatible metrics.
     */
    readonly workspace: IWorkspace;
    /**
     * The underlying CloudFormation resource.
     */
    private readonly anomalyDetector;
    /**
     * The Amazon Resource Name (ARN) of the anomaly detector.
     */
    readonly anomalyDetectorArn: string;
    constructor(scope: Construct, id: string, props: AnomalyDetectorProps);
}
