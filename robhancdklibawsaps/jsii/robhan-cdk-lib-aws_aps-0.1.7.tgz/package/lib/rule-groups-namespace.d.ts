import { IWorkspaceRef } from 'aws-cdk-lib/aws-aps';
import { Construct } from 'constructs';
import { IRuleGroupsNamespace, RuleGroupsNamespaceBase } from './rule-groups-namespace-base';
/**
 * Properties for an Amazon Managed Service for Prometheus rule groups namespace.
 */
export interface RuleGroupsNamespaceProps {
    /**
     * The Prometheus rules file as YAML.
     */
    readonly data: string;
    /**
     * The name of the rule groups namespace.
     */
    readonly name: string;
    /**
     * The workspace that contains the rule groups namespace.
     */
    readonly workspace: IWorkspaceRef;
    /**
     * Tags to apply to the rule groups namespace.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * An Amazon Managed Service for Prometheus rule groups namespace.
 */
export declare class RuleGroupsNamespace extends RuleGroupsNamespaceBase {
    /**
     * Reference an existing rule groups namespace by ARN.
     */
    static fromRuleGroupsNamespaceArn(scope: Construct, id: string, ruleGroupsNamespaceArn: string): IRuleGroupsNamespace;
    /**
     * The ARN of the rule groups namespace.
     */
    readonly ruleGroupsNamespaceArn: string;
    private readonly ruleGroupsNamespace;
    constructor(scope: Construct, id: string, props: RuleGroupsNamespaceProps);
}
