import { IResource, Resource, ResourceProps } from 'aws-cdk-lib';
import { AnomalyDetectorReference, CfnAnomalyDetector, IAnomalyDetectorRef } from 'aws-cdk-lib/aws-aps';
import { Construct } from 'constructs';
/**
 * Threshold settings for values close to the expected value.
 */
export declare abstract class IgnoreNearExpected {
    /**
     * Ignore values within a non-negative absolute amount of the expected value.
     */
    static amount(amount: number): IgnoreNearExpected;
    /**
     * Ignore values within a non-negative ratio of the expected value.
     */
    static ratio(ratio: number): IgnoreNearExpected;
    /** @internal */
    abstract _bind(): CfnAnomalyDetector.IgnoreNearExpectedProperty;
}
/**
 * Random Cut Forest configuration for anomaly detection.
 */
export interface RandomCutForestConfiguration {
    /**
     * Values above the expected value that should not be treated as anomalies.
     *
     * @default - no upper tolerance
     */
    readonly ignoreNearExpectedFromAbove?: IgnoreNearExpected;
    /**
     * Values below the expected value that should not be treated as anomalies.
     *
     * @default - no lower tolerance
     */
    readonly ignoreNearExpectedFromBelow?: IgnoreNearExpected;
    /**
     * The PromQL query evaluated by the detector.
     *
     * The service requires the query to be wrapped by one of these aggregation operators: `avg`,
     * `count`, `group`, `max`, `min`, `quantile`, `stddev`, `stdvar`, or `sum`. Query syntax and
     * aggregation semantics are validated by Amazon Managed Service for Prometheus.
     */
    readonly query: string;
    /**
     * The number of data points sampled by the algorithm.
     *
     * @default 256
     */
    readonly sampleSize?: number;
    /**
     * The number of consecutive data points in each shingle.
     *
     * @default 8
     */
    readonly shingleSize?: number;
}
/**
 * Algorithm configuration for an anomaly detector.
 */
export interface AnomalyDetectorConfiguration {
    /**
     * Random Cut Forest algorithm settings.
     */
    readonly randomCutForest: RandomCutForestConfiguration;
}
/**
 * A metric label associated with an anomaly detector.
 */
export interface AnomalyDetectorLabel {
    /**
     * The label key.
     */
    readonly key: string;
    /**
     * The label value.
     */
    readonly value: string;
}
/**
 * The action to take when evaluation data is missing.
 */
export declare enum MissingDataAction {
    /**
     * Treat the missing data point as anomalous.
     */
    MARK_AS_ANOMALY = "MARK_AS_ANOMALY",
    /**
     * Skip evaluation for the missing data point.
     */
    SKIP = "SKIP"
}
/**
 * An Amazon Managed Service for Prometheus anomaly detector.
 */
export interface IAnomalyDetector extends IResource, IAnomalyDetectorRef {
    /**
     * The ARN of the anomaly detector.
     *
     * @attribute
     */
    readonly anomalyDetectorArn: string;
}
/**
 * Base implementation shared by owned and referenced anomaly detectors.
 *
 * @internal
 */
export declare abstract class AnomalyDetectorBase extends Resource implements IAnomalyDetector {
    abstract readonly anomalyDetectorArn: string;
    get anomalyDetectorRef(): AnomalyDetectorReference;
    protected constructor(scope: Construct, id: string, props?: ResourceProps);
}
