import { IKeyRef } from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { IWorkspace, WorkspaceBase, WorkspaceConfiguration, WorkspaceLoggingConfiguration, WorkspaceQueryLoggingConfiguration } from './workspace-base';
/**
 * Properties for an Amazon Managed Service for Prometheus workspace.
 */
export interface WorkspaceProps {
    /**
     * The alert manager definition as YAML.
     *
     * @default - no alert manager definition
     */
    readonly alertManagerDefinition?: string;
    /**
     * A user-assigned alias for the workspace.
     *
     * @default - no alias
     */
    readonly alias?: string;
    /**
     * The customer-managed KMS key used to encrypt workspace data.
     *
     * A managed scraper writing to a workspace encrypted with a customer-managed key requires an
     * explicit scraper role configuration, even when the scraper and workspace share an account.
     * Resource-policy principals also require access to this key.
     *
     * @default - an AWS-owned key
     */
    readonly kmsKey?: IKeyRef;
    /**
     * Rules and alerting logging configuration.
     *
     * @default - rules and alerting logs are not published
     */
    readonly loggingConfiguration?: WorkspaceLoggingConfiguration;
    /**
     * Query logging configuration.
     *
     * @default - queries are not logged
     */
    readonly queryLoggingConfiguration?: WorkspaceQueryLoggingConfiguration;
    /**
     * Workspace retention and ingestion settings.
     *
     * @default - service defaults
     */
    readonly workspaceConfiguration?: WorkspaceConfiguration;
    /**
     * Tags to apply to the workspace.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for referencing an existing workspace.
 */
export interface WorkspaceAttributes {
    /**
     * The ARN of the workspace.
     */
    readonly workspaceArn: string;
    /**
     * The Prometheus-compatible query endpoint.
     *
     * @default - derived from the workspace ARN
     */
    readonly prometheusEndpoint?: string;
}
/**
 * An Amazon Managed Service for Prometheus workspace.
 */
export declare class Workspace extends WorkspaceBase {
    /**
     * Reference an existing workspace by ARN.
     */
    static fromWorkspaceArn(scope: Construct, id: string, workspaceArn: string): IWorkspace;
    /**
     * Reference an existing workspace from its attributes.
     */
    static fromWorkspaceAttributes(scope: Construct, id: string, attrs: WorkspaceAttributes): IWorkspace;
    /**
     * The ARN of the workspace.
     */
    readonly workspaceArn: string;
    /**
     * The unique ID of the workspace.
     */
    readonly workspaceId: string;
    /**
     * The Prometheus-compatible query endpoint for the workspace.
     */
    readonly prometheusEndpoint: string;
    private readonly workspace;
    constructor(scope: Construct, id: string, props?: WorkspaceProps);
}
