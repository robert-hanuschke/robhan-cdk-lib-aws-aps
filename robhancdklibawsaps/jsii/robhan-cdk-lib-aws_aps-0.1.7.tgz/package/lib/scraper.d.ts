import { Construct } from 'constructs';
import { IScraper, ScrapeConfiguration, ScraperBase, ScraperDestination, ScraperLoggingConfiguration, ScraperRoleConfiguration, ScraperSource } from './scraper-base';
/**
 * Properties for an Amazon Managed Service for Prometheus scraper.
 */
export interface ScraperProps {
    /**
     * A user-assigned alias for the scraper.
     *
     * @default - no alias
     */
    readonly alias?: string;
    /**
     * The destination for collected metrics.
     */
    readonly destination: ScraperDestination;
    /**
     * IAM roles used to access the source and destination.
     *
     * Required for cross-account collection and for workspaces encrypted with a customer-managed
     * KMS key. The caller is responsible for the roles' trust and permissions.
     *
     * @default - service-created roles
     */
    readonly roleConfiguration?: ScraperRoleConfiguration;
    /**
     * The Prometheus scrape configuration.
     */
    readonly scrapeConfiguration: ScrapeConfiguration;
    /**
     * Diagnostic logging configuration.
     *
     * @default - scraper diagnostic logging is disabled
     */
    readonly loggingConfiguration?: ScraperLoggingConfiguration;
    /**
     * The source from which metrics are collected.
     */
    readonly source: ScraperSource;
    /**
     * Tags to apply to the scraper.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * An Amazon Managed Service for Prometheus scraper.
 */
export declare class Scraper extends ScraperBase {
    /**
     * Reference an existing scraper by ARN.
     */
    static fromScraperArn(scope: Construct, id: string, scraperArn: string): IScraper;
    /**
     * The ARN of the scraper.
     */
    readonly scraperArn: string;
    /**
     * The unique ID of the scraper.
     */
    readonly scraperId: string;
    /**
     * The ARN of the service-created scraper role.
     *
     * This attribute is available on scrapers created by this construct. It is intentionally not on
     * `IScraper`, because the role ARN cannot be derived when referencing a scraper by ARN alone.
     */
    readonly scraperRoleArn: string;
    private readonly scraper;
    constructor(scope: Construct, id: string, props: ScraperProps);
}
