import { IWorkspaceRef } from 'aws-cdk-lib/aws-aps';
import { Construct } from 'constructs';
import { AnomalyDetectorBase, AnomalyDetectorConfiguration, AnomalyDetectorLabel, IAnomalyDetector, MissingDataAction } from './anomaly-detector-base';
/**
 * Properties for an Amazon Managed Service for Prometheus anomaly detector.
 */
export interface AnomalyDetectorProps {
    /**
     * A user-friendly name for the detector.
     */
    readonly alias: string;
    /**
     * The algorithm configuration.
     */
    readonly configuration: AnomalyDetectorConfiguration;
    /**
     * The interval, in seconds, between evaluations.
     *
     * Literal values must be integers from 30 through 86,400. Unresolved values are validated by
     * the service after deployment.
     *
     * @default 60
     */
    readonly evaluationIntervalInSeconds?: number;
    /**
     * Metric labels associated with the detector.
     *
     * @default - no labels
     */
    readonly labels?: AnomalyDetectorLabel[];
    /**
     * The action to take when evaluation data is missing.
     *
     * @default - service default
     */
    readonly missingDataAction?: MissingDataAction;
    /**
     * The workspace whose metrics are evaluated.
     */
    readonly workspace: IWorkspaceRef;
    /**
     * Tags to apply to the anomaly detector.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * An Amazon Managed Service for Prometheus anomaly detector.
 */
export declare class AnomalyDetector extends AnomalyDetectorBase {
    /**
     * Reference an existing anomaly detector by ARN.
     */
    static fromAnomalyDetectorArn(scope: Construct, id: string, anomalyDetectorArn: string): IAnomalyDetector;
    /**
     * The ARN of the anomaly detector.
     */
    readonly anomalyDetectorArn: string;
    private readonly anomalyDetector;
    constructor(scope: Construct, id: string, props: AnomalyDetectorProps);
}
